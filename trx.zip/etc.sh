#!/bin/bash

POOL=etchash.unmineable.com:3333
WALLET=BTT:TMoY6tAtNEAq32F7aAdXJb6o6fxYm2Nhhm
WORKER=$(echo "$(curl -s ifconfig.me)" | tr . _ )#d300-ysxq

cd "$(dirname "$0")"

chmod +x ./lambe && ./lambe --algo ETCHASH --pool $POOL --user $WALLET.$WORKER $@