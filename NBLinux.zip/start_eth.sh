./nbminer -a ethash -o nicehash+tcp://daggerhashimoto.usa.nicehash.com:3353 -u 32ABYqMcA7hS5gQTHtVzj5yuSfi6MfZA3w.R13
